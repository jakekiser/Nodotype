function loadTxt()
	{
    document.getElementById("txtLang").innerHTML = "Word-Text hier einf\u00fcgen";
    document.getElementById("btnCancel").value = "Abbrechen";
    document.getElementById("btnOk").value = " OK ";   
	}
function writeTitle()
	{
	document.write("<title>Word-Text einf\u00fcgen</title>")
	}
