function fValidateForm(oForm) {
var bError=0;
var bFieldsRequired=0;
var bWrongEmailFormat=0;

	var pars = oForm.getElementsByTagName('input');
	for (var i=0;i<pars.length;i++) {
		pars[i].style.border = '#ccc 1px solid';
	}		
	for (var i=0;i<pars.length;i++) {
		// Check for value exists if required
		if (pars[i].className.indexOf('xf_Required')!=-1 && pars[i].value.length<1) {
			pars[i].style.border = 'red 1px solid';
			bError=1;
			bFieldsRequired=1;
		}
		// Check for valid email format if email field
		if (pars[i].className.indexOf('xf_Email')!=-1 && pars[i].value.length>0 && !isValidEmail(pars[i].value)) {
			pars[i].style.border = 'red 1px solid';
			bError=1;
			bWrongEmailFormat=1;
		}		
	}   
	if (bError==1 && bFieldsRequired==1) {
	  alert ('Fields are required');
	}
	if (bError==1 && bWrongEmailFormat==1) {
	  alert ('Email field found that is an incorrect format');
	}	
	
	if (bError==1) {
		return false;
	}

	if (document.getElementById('UpdInd')) {
		document.getElementById('UpdInd').value=1;
	}
	
	oForm.submit();
         
}
