function loadTxt()
    {
    document.getElementById("txtLang").innerHTML = "Wollen Sie diesen Ordner wirklich l\u00F6schen?";

    document.getElementById("btnClose").value = "schlie\u00DFen";
    document.getElementById("btnDelete").value = "l\u00F6schen";
    }
function writeTitle()
    {
    document.write("<title>"+"Ordner l\u00F6schen"+"</title>")
    }
