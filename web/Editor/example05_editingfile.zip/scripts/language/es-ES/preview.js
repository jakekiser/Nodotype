function loadTxt()
    {
    document.getElementById("btnClose").value = "Cerrar";
    }
function writeTitle()
    {
    document.write("<title>Vista previa</title>")
    }