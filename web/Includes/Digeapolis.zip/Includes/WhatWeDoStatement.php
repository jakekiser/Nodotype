<div id="WhatWeDo">
    <p>Digiapolis is an interactive web development and marketing company focused on delivering opportunities to your business bringing bold marketing ideas, 
        an effective use of technology, and a passion for execution.</p>
</div>