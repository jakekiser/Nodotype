function isNumOrChar (InString)  {
	if(InString.length < 1) 
		return true;

  var iChars = "!@#$%^&*()+=[]\\\';,./{}|\":<>?";
  var l_SpecialCharacterFound = 0
  
  for (var i = 0; i < InString.length; i++) {
  	if (iChars.indexOf(InString.charAt(i)) != -1) {
	  	l_SpecialCharacterFound = 1;
	}
  }
	if (l_SpecialCharacterFound ) {
  		return false;
	 	}
	else {
		return true;
	}
}
function isNum (InString)  {
if(InString.length < 1) 
		return true;

  var iChars = "1234567890";
  var l_NonNumericFound = 0;
  
  for (var i = 0; i < InString.length; i++) {
  	if (iChars.indexOf(InString.charAt(i)) == -1) {
	  	l_NonNumericFound = 1;
	}
  }
	if (l_NonNumericFound) {
  		return false;
	 	}
	else {
		return true;
	}
}
function isValidEmail(InString)
{
if(InString.length < 1) 
		return true;
  var result = false
  var theStr = new String(InString)
  var index = theStr.indexOf("@");
  if (index > 0)
  {
    var pindex = theStr.indexOf(".",index);
    if ((pindex > index+1) && (theStr.length > pindex+1))
	result = true;
  }
  return result;
}