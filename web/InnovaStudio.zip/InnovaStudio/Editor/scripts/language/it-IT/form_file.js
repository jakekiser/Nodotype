function loadTxt()
    {
    document.getElementById("txtLang").innerHTML = "Nome";
    
    document.getElementById("btnCancel").value = "cancella";
    document.getElementById("btnInsert").value = "inserisci";
    document.getElementById("btnApply").value = "applica a";
    document.getElementById("btnOk").value = " ok ";
    }
function writeTitle()
    {
    document.write("<title>Campo del file</title>")
    }