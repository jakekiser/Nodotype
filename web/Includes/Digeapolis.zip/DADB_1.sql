CREATE PROCEDURE `spDAInsUser`(IN pLastName VARCHAR(255),IN pFirstName VARCHAR(255),IN pEmail VARCHAR(255),IN pCompanyName VARCHAR(255))
BEGIN
declare vLastId bigInt;

    INSERT INTO DA_User
        (
            LastName,
            FirstName,
            CompanyName
        )
    VALUES (
            pLastName,
            pFirstName,
            pCompanyName
        );
    
    set vLastId=LAST_INSERT_ID();

    Insert into DA_EmailAccounts 
        (
            UserId,
            Email
        )
    values (
            vLastId,
            pEmail
    );


select vLastId as LastId;
END