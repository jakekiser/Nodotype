<style>
    #imgLogo, #imgLogoSmall {display:none;}
    body {background-color:#fff;}
</style>
<div id="MainPane">
    <div id="BigLogo">
        <div><img id="DigiLogo" src="images/DA_BigLogo.png" /></div>
        <div id="SocialLinks">
            <div id="divTwitter"><a title="Visit us on Twitter" href="http://www.twitter.com/Digiapolis" target="_blank"><img src="/images/DA_Twitter.png" /></a></div>
            <div id="divFaceBook"><a title="Visit us on FaceBook" href="http://www.facebook.com/Digiapolis" target="_blank"><img src="/images/DA_Facebook.png" /></a></div>
            <br class="ClearFloatManual" />
        </div>
        </div>
    </div>
    <div id="KeyMessages">
        <span><a href="#WebDevelopment">Web Development</a></span>
        <span><a href="#ResponsiveMarketing">Responsive Marketing</a></span>
        <span><a href="#BusinessSocial">Business Social</a></span>
    </div>
<div style="display:none;" class="UnderConstruction"><small>This site is still under construction - ETA: 1/14/2013</small></div>
<!-- AddThis Button BEGIN -->
<div class="addthis_toolbox addthis_default_style ">
    <a class="addthis_button_facebook_like" fb:like:layout="button_count"></a>
    <a class="addthis_button_tweet"></a>
    <a class="addthis_counter addthis_pill_style"></a>
</div>
<script type="text/javascript">var addthis_config = {"data_track_addressbar":true};</script>
<script type="text/javascript" src="//s7.addthis.com/js/300/addthis_widget.js#pubid=ra-50f6bc4716b349b0"></script>
<!-- AddThis Button END -->
</div>