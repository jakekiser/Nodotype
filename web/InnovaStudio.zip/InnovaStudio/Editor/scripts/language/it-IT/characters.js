function loadTxt()
    {
    document.getElementById("txtLang").innerHTML = "Codice HTML";
    document.getElementById("btnClose").value = "chiudi";
    }
function writeTitle()
    {
    document.write("<title>Caratteri Speciali</title>")
    }