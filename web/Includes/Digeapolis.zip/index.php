<? 
require 'Includes/RSSUtilities.php';
require 'Includes/HTMLBuildClass.php';

$A=new BuildClass();
$A->BuildTopHTML();
?>
<link rel="stylesheet" href="CSS/reset.css" type="text/css" />
<link rel="stylesheet" href="CSS/Basic_1112013.css" type="text/css" />
<link rel="stylesheet" href="CSS/Form_172013.css" type="text/css" />
<?
    if ($browser=='iphone') {
?>
<link rel="stylesheet" href="CSS/iPhone_1112013.css" type="text/css" />
<?
    }
?>
<body>
    <a id="TopOfPage" class="StdScrollAnchor"></a>
    <div id=BodyContainer>
        <div id=Body>
            <div id="LeftPane">
                <div id=Logo><a href="http://www.Digiapolis.com"><img id=imgLogo src="images/DigiapolisSmallLogo.png"/><img id=imgLogoSmall src="images/DigiapolisLogoWhiteLO.png"/></a>
                    <ul id=LeftMenu>
                        <li id=About class=<? echo $sAboutSelectedClass ?>><a href="?p=About"><div>About<div>&nbsp;</div></div></a></li>
                        <li id=Contact class=<? echo $sContactSelectedClass ?>><a href="?p=Contact"><div>Contact<div>&nbsp;</div></div></a></li>
                        <li id=Blog><a href="http://ChiefSocialStrategist.com"><div>Blog<div>&nbsp;</div></div></a></li>
                        <li id=Clear class="ClearFloat">&nbsp;</li>
                    </ul>
                    <br class="ClearFloat" />
                </div>
            </div>
<?
$A->BuildPageContent($Func);
?>
        </div>
</div>
<?
if ($Func=='Home') {
    require 'Includes/WhatWeDoStatement.php';
    $A->BuildPageContent('ServiceTiles');
    echo '<div id=ScrollPageContainer>';
    require 'Includes/WebDevelopment.php';
    require 'Includes/ResponsiveMarketing.php';
    require 'Includes/BusinessSocial.php';
    require 'Includes/Skills.php';
    echo '</div>';
}
?> 
<script type="text/javascript" src="JSLibrary/jquery-1.8.3.min.js"></script>    
<script type="text/javascript" src="JSLibrary/Basic.js"></script>
<script type="text/javascript" src="JSLibrary/GeneralUtilities.js"></script>
<?
$A->BuildBottomHTML();
/*  echo sha1($UserId.$PWD); */
?>
</body>
</html>