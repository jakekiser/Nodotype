<?php
	//Variables for connecting to your database.
	//These variable values come from your hosting account.
	$hostname = "Digeapolis.db.7307520.hostedresource.com";
	$username = "Digeapolis";
	$dbname = "Digeapolis";

	//These variable values need to be changed by you before deploying
	$password = "Esl10036078!";
        
	//Connecting to your database
	mysql_connect($hostname, $username, $password) OR DIE ("Unable to 
	connect to database! Please try again later.");
	mysql_select_db($dbname);
        
        $LastName=$_POST["LastName"];
        $FirstName=$_POST["FirstName"];
        $CompanyName=$_POST["CompanyName"];
        $Email=$_POST["eMail"];
        
	if ($_POST["UpdInd"]=='1') {
		//$SQL='insert into DA_User (LastName, FirstName) values (\''.$_POST["LastName"].'\',\''.$_POST["FirstName"].'\')';
                $SQL='call spDAInsUser (\''.$LastName.'\',\''.$FirstName.'\',\''.$Email.'\',\''.$CompanyName.'\');';
		$result = mysql_query($SQL);
                while($row = mysql_fetch_array($result))
                {
                   // echo 'LastId:'.$row['LastId'];   
                }
		echo '<div class=InfoMsg>Thank you '.$FirstName.', we have recieved your information and will be in contact with you shortly</div>';
	}
?>
<p>Hello!  Though we have not formally launched our new web site yet, we certainly have interest in talking with you.  Please provide your contact information and we will get back to you immediately.</p>
<p>Regards, Eric</p><hr/>
<div id="divForm">
    <form class="BasicForm" name="formContactUs" id="formContactUs" method="post" action="" onsubmit="return(fValidateForm(this))">
        <input type="hidden" name="UpdInd" id="UpdInd"/>
        <div class="StdRow">
            <div class="StdLabel">* First Name</div>
            <div class="StdInput Required"><input class="xf_Alpha xf_Required" type="text" name="FirstName" id="FirstName"/></div>
            <br class="ClearFix"/>
        </div>
        <div class="StdRow">
            <div class="StdLabel">* Last Name</div>
            <div class="StdInput Required"><input class="xf_Alpha xf_Required" type="text" name="LastName" id="LastName"/></div>
            <br class="ClearFix"/>
        </div>
        <div class="StdRow">
            <div class="StdLabel">* Email</div>
            <div class="StdInput Required"><input class="xf_Alpha xf_Required xf_Email" type="text" name="eMail" id="eMail"/></div>
            <br class="ClearFix"/>
        </div>					
        <div class="StdRow">
            <div class="StdLabel">Company Name</div>
            <div class="StdInput"><input class="xf_Alpha" type="text" name="CompanyName" id="CompanyName"/></div>
            <br class="ClearFix"/>
        </div>	
        <div class="StdRow">
            <div class="StdLabel">* Phone</div>
            <div class="StdInput Required"><input class="xf_Alpha xf_Required" type="text" name="Phone" id="Phone"/></div>
            <br class="ClearFix"/>
        </div>
        <div class="StdRow Footer Action">
            <input class="ActionButton" type="submit" value="Submit"/>
        </div>
    </form>
</div>
