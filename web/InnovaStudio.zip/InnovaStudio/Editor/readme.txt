InnovaStudio WYSIWYG Editor 5.5
Copyright � 2011, INNOVA STUDIO (www.InnovaStudio.com). All rights reserved.
____________________________________________________________________


*** Installation ***
1. Unzip the package & copy all files into your web folder.
(To run several examples, it is recomended that you copy all files into http://yourserver/Editor/  or http://localhost/Editor/)
2. To browse the examples, open default.htm 
(http://yourserver/Editor/default.htm  or http://localhost/Editor/default.htm)


*** Upgrade & Support ***
We provide 1 year FREE upgrade and support (support@InnovaStudio.com) for every purchase of license. 


*** IMPORTANT NOTE ***

ASSET MANAGER 

ASSET MANAGER IS FREE ADD-ON INCLUDED IN INNOVASTUDIO WYSIWYG EDITOR PACKAGE.
SINCE ASSET MANAGER IS A STANDALONE APPLICATION AND CAN BE ACCESSED DIRECTLY
FROM BROWSER, YOU WILL NEED TO SECURE IT BY ADDING USER CHECK/AUTHENTICATION
TO ASSETMANAGER.ASP/PHP/ASPX. SECURITY CHECK MUST ALSO BE ADDED TO OTHER FILES IN 
ASSETMANAGER FOLDER SUCH AS FOLDERNEW.ASP/PHP, FOLDERDEL.ASP/PHP.

In addition to that, you may also want to set allowed file types in asset manager.

To set allowed file types:
1. ASP version, in i_upload_object_FSO.asp, line 234

oUpload.AllowedTypes = "gif|jpg|png|wma|wmv|swf|doc|zip|pdf|txt"

2. PHP version, in assetmanager.php line 26

$AllowedTypes = "gif|jpg|png|wma|wmv|swf|doc|zip|pdf|txt";


*** INCLUDED SCRIPTS ***


jQuery JavaScript Library v1.4.2
http://jquery.com/
Copyright 2010, John Resig
Dual licensed under the MIT or GPL Version 2 licenses.
http://jquery.org/license


WordPress Audio Player 
http://wpaudioplayer.com/standalone
Copyright (c) 2008 Martin Laine
Audio Player is released under the Open Source MIT license.



Thank you for using our product.

____________________________________________________________________
http://www.InnovaStudio.com
