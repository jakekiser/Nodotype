function loadTxt()
    {
    var txtLang = document.getElementsByName("txtLang");
    txtLang[0].innerHTML = "Source";
    txtLang[1].innerHTML = "Signet";
    txtLang[2].innerHTML = "Cible";
    txtLang[3].innerHTML = "Titre";
    txtLang[4].innerHTML = "Rel";

    var optLang = document.getElementsByName("optLang");
    optLang[0].text = "M\u00EAme page"
    optLang[1].text = "Nouvelle page"
    optLang[2].text = "Page parente"
    
    document.getElementById("btnCancel").value = "Annuler";
    document.getElementById("btnInsert").value = "Ins\u00E9rer";
    document.getElementById("btnApply").value = "Actualiser";
    document.getElementById("btnOk").value = " ok ";
    }
function writeTitle()
    {
    document.write("<title>Ins\u00E9rer un lien hypertexte</title>")
    }