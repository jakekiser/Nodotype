<style>
    #imgLogo, #imgLogoSmall {display:none;}
    body {background-color:#fff;}
</style>
<div id="MainPane">
    <div id="BigLogo">
        <div><img id="DigiLogo" src="images/DA_BigLogo.png" /></div>
        <div id="SocialLinks">
            <div id="divTwitter"><a title="Visit us on Twitter" href="http://www.twitter.com/Digiapolis" target="_blank"><img src="/images/DA_Twitter.png" /></a></div>
            <div id="divFaceBook"><a title="Visit us on FaceBook" href="http://www.facebook.com/Digiapolis" target="_blank"><img src="/images/DA_Facebook.png" /></a></div>
            <br class="ClearFloatManual" />
        </div>
        </div>
    </div>
    <div id="KeyMessages">
        <span><a href="#WebDevelopment">Web Development</a></span>
        <span><a href="#ResponsiveMarketing">Responsive Marketing</a></span>
        <span><a href="#BusinessSocial">Business Social</a></span>
    </div>
<div style="display:none;" class="UnderConstruction"><small>This site is still under construction - ETA: 1/14/2013</small></div>
</div>