function loadTxt()
	{
    document.getElementById("txtLang").innerHTML = "Plak hier uw tekst inhoud (CTRL-V) ";
    document.getElementById("btnCancel").value = "annuleren";
    document.getElementById("btnOk").value = " ok ";   
	}
function writeTitle()
	{
	document.write("<title>Tekst plakken</title>")
	}
