<div id="ServiceTiles">
    <div class="BasicTiles">
        <a class="StdScrollAnchor" href='#WebDevelopment'>
            <div class="ServiceTile STBlue STWebDevelopment">
                <div class="ServiceImage"><img src="/images/DA_WebDevelopment.png"/></div>
                <div class="ServiceText"    >Web Development</div>
            </div>
        </a>
        <a class="StdScrollAnchor" href='#ResponsiveMarketing'>
            <div class="ServiceTile STOrange STResponsiveMarketing">
                <div class="ServiceImage"><img src="/images/DA_ResponsiveMarketing.png"/></div>
                <div class="ServiceText">Responsive Marketing</div>
            </div>
        </a>
        <a class="StdScrollAnchor" href='#BusinessSocial'>
            <div class="ServiceTile STGreen STBusinessSocial">
                <div class="ServiceImage"><img src="/images/DA_BusinessSocial.png"/></div>
                <div class="ServiceText">Business Social</div>
            </div>
        </a>
        <a class="StdScrollAnchor" href='#Skills'>
            <div class="ServiceTile STBlue STSkills">
                <div class="ServiceImage"><img src="/images/DA_Skills.png"/></div>
                <div class="ServiceText">Skills</div>
            </div>
        </a>
        <div class="ServiceTile STPeople">
            <img src="/images/People.jpg"/>
        </div>
        <br class="ClearFloatManual" />
    </div>
    <div id="RSSTileContainer">
        <div id="RSSTile"><h3>@Digiapolis - Just In</h3>
<?
$A2=new BuildRSSClass();
$A2->BuildRSS();
?>
        </div>
    </div>
    <br class="ClearFloat"/>
</div>
