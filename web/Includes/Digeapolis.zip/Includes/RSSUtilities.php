<?
class BuildRSSClass {
    public function BuildRSS() {
    
        $rss = new DOMDocument();
        $rss->load('http://feeds.feedburner.com/twitter/digiapolis');    
    
        $feed = array();
        foreach ($rss->getElementsByTagName('item') as $node) {
            $item = array ( 
                'title' => $node->getElementsByTagName('title')->item(0)->nodeValue,
                'desc' => $node->getElementsByTagName('description')->item(0)->nodeValue,
                'link' => $node->getElementsByTagName('link')->item(0)->nodeValue,
                'date' => $node->getElementsByTagName('pubDate')->item(0)->nodeValue,
            );
            array_push($feed, $item);
        }

        $limit = 3;
        for($x=0;$x<$limit;$x++) {
    	$title = str_replace(' & ', ' &amp; ', $feed[$x]['title']);
            $link = $feed[$x]['link'];
            $description = $feed[$x]['desc'];
            $date = date('m/d/Y h:i:s a', strtotime($feed[$x]['date']));
            //$SocialTime=$this->fTimeDisplay($date);
            $SocialTime=$date;
            echo '<div class="RSSRow">';
            echo '<div class="RSSTitle" ><a target="_blank" href="'.$link.'" title="'.$title.'">'.$title.'</a></div>';
            echo '<div class="RSSDate">'.$SocialTime.'</div>';
            echo '<div class="RSSDesc">'.$description.'</div>';
            echo '</div>';
        }
    }

    public function fTimeDisplay($oDate) {

        $datetime1 = new DateTime($oDate);
        $datetime2 = new DateTime(date('m/d/Y h:i:s a', time()));
        
        //$dateDiff = $datetime1->diff($datetime2);
        $dateDiff = abs(strtotime($datetime1) - strtotime($datetime2));
        $TDDays = floor($dateDiff/(60*60*24));
        $TDHours = floor(($dateDiff-($TDDays*60*60*24))/(60*60));
        $TDMin = floor(($dateDiff-($TDDays*60*60*24)-($TDHours*60*60))/60);

        $TDisplay=$dateDiff.'a moment ago';
        if ($TDMin>0) {
            $TDPlural='';
            if ($TDMin>1) {
                $TDPlural='s';
            }
            $TDisplay=$TDMin.' Minute'.$TDPlural.' ago';
        }

	if ($TDHours>0 && $TDMin>60) {
            $TDPlural='';
            if (TDHours>1) {
                $TDPlural='s';
            }
            $TDisplay=$TDHours.' Hour'.$TDPlural.' ago';
        }	

	if ($TDDays>0 && $TDHours>24) {
            $TDPlural='';
            if ($TDDays>1) {
                $TDPlural='s';
            }		
            $TDisplay=$TDDays.' Day'.$TDPlural.' ago';
        }
		
	if ($TDMM>0 && TDDays > 30) {
            $TDPlural='';
            if ($TDMM>1) {
                $TDPlural='s';
            }		
            $TDisplay=$TDMM.' Month'.$TDPlural.' ago';
        }
		
	return $TDisplay;
}}
?>