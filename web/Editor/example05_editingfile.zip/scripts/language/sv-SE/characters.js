function loadTxt()
    {
    document.getElementById("txtLang").innerHTML = "HTML kod";
    document.getElementById("btnClose").value = "St\u00E4ng";
    }
function writeTitle()
    {
    document.write("<title>Special tecken</title>")
    }