<?php
//Get RequestVariables 
  if(!empty($_GET))
    $Func=$_GET['p'];
  else
    $Func='Home';

  $sContactSelectedClass='';
  $sAboutSelectedClass='';

  switch ($Func) {
    case 'Contact':
        $sContactSelectedClass='Selected';
        break;
    case 'About':
        $sAboutSelectedClass='Selected';
        break;
    }

// Browser Detection
$browser='';
$browser = strpos($_SERVER['HTTP_USER_AGENT'],"iPhone");
if ($browser){
  $browser= 'iphone';
}
if (!$browser){
  $browser = strpos($_SERVER['HTTP_USER_AGENT'],"Windows Phone");
  if ($browser){
    $browser= 'iphone';
  }
}
if (!$browser){
  $browser = strpos($_SERVER['HTTP_USER_AGENT'],"ANDROID");
  if ($browser){
    $browser= 'iphone';
  }
  
 $TestMode=$_GET['tm'];
 if ($TestMode=='1') {
     $browser= 'iphone';
 }
}

class BuildClass
{
public function BuildTopHTML() {
?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html;charset=utf-8" />
<meta http-equiv="X-UA-Compatible" content="IE=edge" />
<meta name="viewport" content="width=320" />
<meta name="viewport" content="initial-scale=1.0" />
<meta name="viewport" content="user-scalable=no" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<meta name="apple-mobile-web-app-status-bar-style" content="black" />
<meta name="apple-mobile-web-app-capable" content="yes" />
<title>Digiapolis.com - Interactive Web Marketing and Development</title>
<link rel="shortcut icon" type="image/xicon" href="images/favicon.ico" />
</head>
<?

}
public function BuildBottomHTML() {
?>
<div id=BottCred>H1, Inc. &copy<? echo date("Y"); ?> | 4330 North Shore Drive, Minneapolis, Minnesota 55364 | <a href="tel:612-860-1025">612-860-1025</a></div>
<script type="text/javascript">
  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-36926763-1']);
  _gaq.push(['_trackPageview']);

  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();

</script>
<?
}
public function BuildPageContent($Page) {

  switch ($Page) {
    case 'Home':
        require 'Includes/Home.php';
        break;
    case 'Contact':
        echo '<h1 class="PageTitle">'.$Page.'</h1>';
        require 'Includes/Contact.php';
        break;
    case 'About':
        echo '<h1 class="PageTitle">'.$Page.'</h1>';
        require 'Includes/About.php';
        break;
    case 'ServiceTiles':
        require 'Includes/ServiceTiles.php';
        break;
    }
  }
}
?>
