function loadTxt()
	{
    document.getElementById("txtLang").innerHTML = "Paste Word content here";
    document.getElementById("btnCancel").value = "cancel";
    document.getElementById("btnOk").value = " ok ";   
	}
function writeTitle()
	{
	document.write("<title>Paste From Word</title>")
	}
