function loadTxt()
    {
    document.getElementById("txtLang").innerHTML = "\u00C3r du s\u00E4ker p\u00E5 att du vill ta bort den h\u00E4r mappen?";

    document.getElementById("btnClose").value = "St\u00E4ng";
    document.getElementById("btnDelete").value = "Ta bort";
    }
function writeTitle()
    {
    document.write("<title>Ta bort mapp</title>")
    }
